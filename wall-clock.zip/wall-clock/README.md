# Wall clock

A Pen created on CodePen.

Original URL: [https://codepen.io/dervondenbergen/pen/dVPOwB](https://codepen.io/dervondenbergen/pen/dVPOwB).

Giant clock to have as fullscreen on a screen while not using it.