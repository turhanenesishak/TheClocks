# HTML 5 Canvas Polar Clock

A Pen created on CodePen.

Original URL: [https://codepen.io/motorlatitude/pen/AXVZjN](https://codepen.io/motorlatitude/pen/AXVZjN).

Inspired by <a href="http://blog.pixelbreaker.com/polarclock"> Flash Polar Clock</a> by pixelbreaker