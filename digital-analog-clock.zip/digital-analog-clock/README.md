# Digital Analog Clock

A Pen created on CodePen.

Original URL: [https://codepen.io/maneeshc/pen/dXqdGz](https://codepen.io/maneeshc/pen/dXqdGz).

A CSS transforms and animations clock. Javascript used to handle & manipulate classes.

Inspired by the Ham Yard Hotel Clock (https://www.youtube.com/watch?v=A-MxGvtK2Bk)

Also, it seems that I really like making clocks.