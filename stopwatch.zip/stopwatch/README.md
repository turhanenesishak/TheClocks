# Stopwatch

A Pen created on CodePen.

Original URL: [https://codepen.io/mmadeira/pen/YWedVR](https://codepen.io/mmadeira/pen/YWedVR).

Inspired by a Dribbble shot from Lorenzo Perniciaro. 

https://dribbble.com/shots/2840735-Stopwatch-Concept