# Circular Calendar Display

A Pen created on CodePen.

Original URL: [https://codepen.io/mattjuggins/pen/WGRRYx](https://codepen.io/mattjuggins/pen/WGRRYx).

A circular calendar and clock display, with and added weather and daily activity widget mock-ups. 