# FLIP CLOCK

A Pen created on CodePen.

Original URL: [https://codepen.io/gametroll/pen/wvozJKv](https://codepen.io/gametroll/pen/wvozJKv).

Just for fun.

Based on this dribbble: https://dribbble.com/shots/14947116