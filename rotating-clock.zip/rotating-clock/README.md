# Rotating Clock

A Pen created on CodePen.

Original URL: [https://codepen.io/VicioBonura/pen/XdYEjR](https://codepen.io/VicioBonura/pen/XdYEjR).

Click the CLOCK to change the style.