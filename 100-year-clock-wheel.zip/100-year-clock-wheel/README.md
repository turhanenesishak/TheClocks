# 100 Year Clock Wheel

A Pen created on CodePen.

Original URL: [https://codepen.io/cbolson/pen/azoVvZm](https://codepen.io/cbolson/pen/azoVvZm).

A 100 year clock wheel with language selection using the built-in JavaScript languages.

I need to work on a responsive solution :thinking: